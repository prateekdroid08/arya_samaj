(function ( $ ) {
	"use strict";

	$(function () {

		// Place your public-facing JavaScript here

	});

}(jQuery));